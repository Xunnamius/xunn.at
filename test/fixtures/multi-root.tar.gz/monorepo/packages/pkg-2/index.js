console.log('dummy monorepo pkg-2 test');
