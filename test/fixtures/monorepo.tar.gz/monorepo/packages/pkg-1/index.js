console.log('dummy monorepo pkg-1 test');
